<template>
  <div class="bg-gray-50 py-24 sm:py-32 dark:bg-gray-900">
    <div class="mx-auto max-w-2xl px-6 lg:max-w-7xl lg:px-8">
      <h2 class="text-base/7 font-semibold text-indigo-600 dark:text-indigo-400">Deploy faster</h2>
      <p class="mt-2 max-w-lg text-4xl font-semibold tracking-tight text-pretty text-gray-900 sm:text-5xl dark:text-white">Everything you need to deploy your app</p>
      <div class="mt-10 grid grid-cols-1 gap-4 sm:mt-16 lg:grid-cols-6 lg:grid-rows-2">
        <div class="flex p-px lg:col-span-4">
          <div class="w-full overflow-hidden rounded-lg bg-white shadow-sm outline outline-black/5 max-lg:rounded-t-4xl lg:rounded-tl-4xl dark:bg-gray-800 dark:shadow-none dark:outline-white/15">
            <img class="h-80 object-cover object-left dark:hidden" src="https://tailwindcss.com/plus-assets/img/component-images/bento-02-releases.png" alt="" />
            <img class="h-80 object-cover object-left not-dark:hidden" src="https://tailwindcss.com/plus-assets/img/component-images/dark-bento-02-releases.png" alt="" />
            <div class="p-10">
              <h3 class="text-sm/4 font-semibold text-gray-500 dark:text-gray-400">Releases</h3>
              <p class="mt-2 text-lg font-medium tracking-tight text-gray-900 dark:text-white">Push to deploy</p>
              <p class="mt-2 max-w-lg text-sm/6 text-gray-600 dark:text-gray-400">Lorem ipsum dolor sit amet, consectetur adipiscing elit. In gravida justo et nulla efficitur, maximus egestas sem pellentesque.</p>
            </div>
          </div>
        </div>
        <div class="flex p-px lg:col-span-2">
          <div class="w-full overflow-hidden rounded-lg bg-white shadow-sm outline outline-black/5 lg:rounded-tr-4xl dark:bg-gray-800 dark:shadow-none dark:outline-white/15">
            <img class="h-80 object-cover dark:hidden" src="https://tailwindcss.com/plus-assets/img/component-images/bento-02-integrations.png" alt="" />
            <img class="h-80 object-cover not-dark:hidden" src="https://tailwindcss.com/plus-assets/img/component-images/dark-bento-02-integrations.png" alt="" />
            <div class="p-10">
              <h3 class="text-sm/4 font-semibold text-gray-500 dark:text-gray-400">Integrations</h3>
              <p class="mt-2 text-lg font-medium tracking-tight text-gray-900 dark:text-white">Connect your favorite tools</p>
              <p class="mt-2 max-w-lg text-sm/6 text-gray-600 dark:text-gray-400">Curabitur auctor, ex quis auctor venenatis, eros arcu rhoncus massa.</p>
            </div>
          </div>
        </div>
        <div class="flex p-px lg:col-span-2">
          <div class="w-full overflow-hidden rounded-lg bg-white shadow-sm outline outline-black/5 lg:rounded-bl-4xl dark:bg-gray-800 dark:shadow-none dark:outline-white/15">
            <img class="h-80 object-cover dark:hidden" src="https://tailwindcss.com/plus-assets/img/component-images/bento-02-security.png" alt="" />
            <img class="h-80 object-cover not-dark:hidden" src="https://tailwindcss.com/plus-assets/img/component-images/dark-bento-02-security.png" alt="" />
            <div class="p-10">
              <h3 class="text-sm/4 font-semibold text-gray-500 dark:text-gray-400">Security</h3>
              <p class="mt-2 text-lg font-medium tracking-tight text-gray-900 dark:text-white">Advanced access control</p>
              <p class="mt-2 max-w-lg text-sm/6 text-gray-600 dark:text-gray-400">Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia.</p>
            </div>
          </div>
        </div>
        <div class="flex p-px lg:col-span-4">
          <div class="w-full overflow-hidden rounded-lg bg-white shadow-sm outline outline-black/5 max-lg:rounded-b-4xl lg:rounded-br-4xl dark:bg-gray-800 dark:shadow-none dark:outline-white/15">
            <img class="h-80 object-cover object-left dark:hidden" src="https://tailwindcss.com/plus-assets/img/component-images/bento-02-performance.png" alt="" />
            <img class="h-80 object-cover object-left not-dark:hidden" src="https://tailwindcss.com/plus-assets/img/component-images/dark-bento-02-performance.png" alt="" />
            <div class="p-10">
              <h3 class="text-sm/4 font-semibold text-gray-500 dark:text-gray-400">Performance</h3>
              <p class="mt-2 text-lg font-medium tracking-tight text-gray-900 dark:text-white">Lightning-fast builds</p>
              <p class="mt-2 max-w-lg text-sm/6 text-gray-600 dark:text-gray-400">Sed congue eros non finibus molestie. Vestibulum euismod augue vel commodo vulputate. Maecenas at augue sed elit dictum vulputate.</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
