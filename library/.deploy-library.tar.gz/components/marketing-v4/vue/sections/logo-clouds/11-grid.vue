<template>
  <div class="bg-white py-24 sm:py-32 dark:bg-gray-900">
    <div class="mx-auto max-w-7xl px-6 lg:px-8">
      <div class="-mx-6 grid grid-cols-2 gap-0.5 overflow-hidden sm:mx-0 sm:rounded-2xl md:grid-cols-3">
        <div class="bg-gray-400/5 p-8 sm:p-10 dark:bg-white/5">
          <img class="max-h-12 w-full object-contain dark:hidden" src="https://tailwindcss.com/plus-assets/img/logos/158x48/transistor-logo-gray-900.svg" alt="Transistor" width="158" height="48" />
          <img class="max-h-12 w-full object-contain not-dark:hidden" src="https://tailwindcss.com/plus-assets/img/logos/158x48/transistor-logo-white.svg" alt="Transistor" width="158" height="48" />
        </div>
        <div class="bg-gray-400/5 p-6 sm:p-10 dark:bg-white/5">
          <img class="max-h-12 w-full object-contain dark:hidden" src="https://tailwindcss.com/plus-assets/img/logos/158x48/reform-logo-gray-900.svg" alt="Reform" width="158" height="48" />
          <img class="max-h-12 w-full object-contain not-dark:hidden" src="https://tailwindcss.com/plus-assets/img/logos/158x48/reform-logo-white.svg" alt="Reform" width="158" height="48" />
        </div>
        <div class="bg-gray-400/5 p-6 sm:p-10 dark:bg-white/5">
          <img class="max-h-12 w-full object-contain dark:hidden" src="https://tailwindcss.com/plus-assets/img/logos/158x48/tuple-logo-gray-900.svg" alt="Tuple" width="158" height="48" />
          <img class="max-h-12 w-full object-contain not-dark:hidden" src="https://tailwindcss.com/plus-assets/img/logos/158x48/tuple-logo-white.svg" alt="Tuple" width="158" height="48" />
        </div>
        <div class="bg-gray-400/5 p-6 sm:p-10 dark:bg-white/5">
          <img class="max-h-12 w-full object-contain dark:hidden" src="https://tailwindcss.com/plus-assets/img/logos/158x48/laravel-logo-gray-900.svg" alt="Laravel" width="158" height="48" />
          <img class="max-h-12 w-full object-contain not-dark:hidden" src="https://tailwindcss.com/plus-assets/img/logos/158x48/laravel-logo-white.svg" alt="Laravel" width="158" height="48" />
        </div>
        <div class="bg-gray-400/5 p-6 sm:p-10 dark:bg-white/5">
          <img class="max-h-12 w-full object-contain dark:hidden" src="https://tailwindcss.com/plus-assets/img/logos/158x48/savvycal-logo-gray-900.svg" alt="SavvyCal" width="158" height="48" />
          <img class="max-h-12 w-full object-contain not-dark:hidden" src="https://tailwindcss.com/plus-assets/img/logos/158x48/savvycal-logo-white.svg" alt="SavvyCal" width="158" height="48" />
        </div>
        <div class="bg-gray-400/5 p-6 sm:p-10 dark:bg-white/5">
          <img class="max-h-12 w-full object-contain dark:hidden" src="https://tailwindcss.com/plus-assets/img/logos/158x48/statamic-logo-gray-900.svg" alt="Statamic" width="158" height="48" />
          <img class="max-h-12 w-full object-contain not-dark:hidden" src="https://tailwindcss.com/plus-assets/img/logos/158x48/statamic-logo-white.svg" alt="Statamic" width="158" height="48" />
        </div>
      </div>
    </div>
  </div>
</template>
