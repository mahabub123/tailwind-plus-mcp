<template>
  <div class="bg-white py-24 sm:py-32 dark:bg-gray-900">
    <div class="mx-auto max-w-7xl px-6 lg:px-8">
      <div class="mx-auto max-w-2xl lg:max-w-none">
        <h2 class="text-lg/8 font-semibold text-gray-900 dark:text-white">Trusted by the world’s most innovative teams</h2>
        <div class="mx-auto mt-10 grid grid-cols-4 items-start gap-x-8 gap-y-10 sm:grid-cols-6 sm:gap-x-10 lg:mx-0 lg:grid-cols-5">
          <img class="col-span-2 max-h-12 w-full object-contain object-left lg:col-span-1 dark:hidden" src="https://tailwindcss.com/plus-assets/img/logos/transistor-logo-gray-900.svg" alt="Transistor" width="158" height="48" />
          <img class="col-span-2 max-h-12 w-full object-contain object-left not-dark:hidden lg:col-span-1" src="https://tailwindcss.com/plus-assets/img/logos/transistor-logo-white.svg" alt="Transistor" width="158" height="48" />

          <img class="col-span-2 max-h-12 w-full object-contain object-left lg:col-span-1 dark:hidden" src="https://tailwindcss.com/plus-assets/img/logos/reform-logo-gray-900.svg" alt="Reform" width="158" height="48" />
          <img class="col-span-2 max-h-12 w-full object-contain object-left not-dark:hidden lg:col-span-1" src="https://tailwindcss.com/plus-assets/img/logos/reform-logo-white.svg" alt="Reform" width="158" height="48" />

          <img class="col-span-2 max-h-12 w-full object-contain object-left lg:col-span-1 dark:hidden" src="https://tailwindcss.com/plus-assets/img/logos/tuple-logo-gray-900.svg" alt="Tuple" width="158" height="48" />
          <img class="col-span-2 max-h-12 w-full object-contain object-left not-dark:hidden lg:col-span-1" src="https://tailwindcss.com/plus-assets/img/logos/tuple-logo-white.svg" alt="Tuple" width="158" height="48" />

          <img class="col-span-2 max-h-12 w-full object-contain object-left lg:col-span-1 dark:hidden" src="https://tailwindcss.com/plus-assets/img/logos/savvycal-logo-gray-900.svg" alt="SavvyCal" width="158" height="48" />
          <img class="col-span-2 max-h-12 w-full object-contain object-left not-dark:hidden lg:col-span-1" src="https://tailwindcss.com/plus-assets/img/logos/savvycal-logo-white.svg" alt="SavvyCal" width="158" height="48" />

          <img class="col-span-2 max-h-12 w-full object-contain object-left lg:col-span-1 dark:hidden" src="https://tailwindcss.com/plus-assets/img/logos/statamic-logo-gray-900.svg" alt="Statamic" width="158" height="48" />
          <img class="col-span-2 max-h-12 w-full object-contain object-left not-dark:hidden lg:col-span-1" src="https://tailwindcss.com/plus-assets/img/logos/statamic-logo-white.svg" alt="Statamic" width="158" height="48" />
        </div>
      </div>
    </div>
  </div>
</template>
