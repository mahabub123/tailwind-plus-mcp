<template>
  <div class="bg-indigo-700">
    <div class="px-6 py-24 sm:py-32 lg:px-8">
      <div class="mx-auto max-w-2xl text-center">
        <h2 class="text-4xl font-semibold tracking-tight text-balance text-white sm:text-5xl">Boost your productivity. Start using our app today.</h2>
        <p class="mx-auto mt-6 max-w-xl text-lg/8 text-pretty text-indigo-200">Incididunt sint fugiat pariatur cupidatat consectetur sit cillum anim id veniam aliqua proident excepteur commodo do ea.</p>
        <div class="mt-10 flex items-center justify-center gap-x-6">
          <a href="#" class="rounded-md bg-white px-3.5 py-2.5 text-sm font-semibold text-indigo-600 shadow-xs hover:bg-indigo-50 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-white dark:shadow-none"> Get started </a>
          <a href="#" class="text-sm/6 font-semibold text-white">
            Learn more
            <span aria-hidden="true">→</span>
          </a>
        </div>
      </div>
    </div>
  </div>
</template>
