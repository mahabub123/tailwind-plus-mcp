<template>
  <div class="overflow-hidden bg-white py-24 sm:py-32 dark:bg-gray-900">
    <div class="mx-auto max-w-7xl px-6 lg:px-8">
      <p class="max-w-2xl text-5xl font-semibold tracking-tight text-pretty text-gray-900 sm:text-6xl sm:text-balance dark:text-white">Everything you need to deploy your app</p>
      <div class="relative mt-16 aspect-2432/1442 h-144 sm:h-auto sm:w-[calc(var(--container-7xl)-(--spacing(16)))]">
        <div class="absolute -inset-2 rounded-[calc(var(--radius-xl)+(--spacing(2)))] shadow-xs ring-1 ring-black/5 dark:bg-white/2.5 dark:ring-white/10"></div>
        <img alt="" src="https://tailwindcss.com/plus-assets/img/component-images/project-app-screenshot.png" class="h-full rounded-xl shadow-2xl ring-1 ring-black/10 dark:hidden dark:ring-white/10" />
        <img alt="" src="https://tailwindcss.com/plus-assets/img/component-images/dark-project-app-screenshot.png" class="h-full rounded-xl shadow-2xl ring-1 ring-black/10 not-dark:hidden dark:ring-white/10" />
      </div>
    </div>
  </div>
</template>
