<template>
  <div class="bg-white px-6 py-24 sm:py-32 lg:px-8 dark:bg-gray-900">
    <div class="mx-auto max-w-2xl text-center">
      <h2 class="text-5xl font-semibold tracking-tight text-gray-900 sm:text-7xl dark:text-white">Support center</h2>
      <p class="mt-8 text-lg font-medium text-pretty text-gray-500 sm:text-xl/8 dark:text-gray-400">Anim aute id magna aliqua ad ad non deserunt sunt. Qui irure qui lorem cupidatat commodo. Elit sunt amet fugiat veniam occaecat fugiat.</p>
    </div>
  </div>
</template>
